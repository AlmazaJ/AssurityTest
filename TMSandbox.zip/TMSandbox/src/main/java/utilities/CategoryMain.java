package utilities;

public class CategoryMain {

    // Declare variables
    String categoryName = "Carbon credits";
    String promotionsName = "Gallery";
    String promotionsDescription = "Good position in category";
    String url = "https://api.tmsandbox.co.nz/v1/Categories/6327/Details.json?catalogue=false";

}
